import { TestBed } from '@angular/core/testing';

import { DisplayInfoCardService } from './display-info-card.service';

describe('DisplayInfoCardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DisplayInfoCardService = TestBed.get(DisplayInfoCardService);
    expect(service).toBeTruthy();
  });
});
