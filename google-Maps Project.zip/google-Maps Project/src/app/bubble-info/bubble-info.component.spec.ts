import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BubbleInfoComponent } from './bubble-info.component';

describe('BubbleInfoComponent', () => {
  let component: BubbleInfoComponent;
  let fixture: ComponentFixture<BubbleInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BubbleInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BubbleInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
