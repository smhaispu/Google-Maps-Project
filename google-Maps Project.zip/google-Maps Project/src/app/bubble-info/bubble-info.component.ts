import { Component, OnInit, Inject } from '@angular/core';
import {ItemsInterface}  from '../models/pincodeItems';
import { MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'app-bubble-info',
  templateUrl: './bubble-info.component.html',
  styleUrls: ['./bubble-info.component.css']
})
export class BubbleInfoComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: ItemsInterface) { 
  }

  ngOnInit() {
  }

}
