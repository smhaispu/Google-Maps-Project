export interface ItemsInterface {
        id: string;
        address: number;
        latitude: number;
        longitude: number;
      }
