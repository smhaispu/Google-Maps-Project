import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  pinCodeData: string[];
  jsonUrl = './assets/fakeBackEnd.json';
  constructor(private http: HttpClient) { }
  getData() {
    return this.http.get(this.jsonUrl);
  }
}
