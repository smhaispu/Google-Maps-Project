import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { PinSearchComponent } from './pin-search/pin-search.component';
import { AgmCoreModule } from '@agm/core';
import { DataTableComponent } from './data-table/data-table.component';
import {MatFormFieldModule } from '@angular/material/form-field';
import { MatDialogModule} from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PaginationService } from './pagination.service';
import { BubbleInfoComponent } from './bubble-info/bubble-info.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    PinSearchComponent,
    DataTableComponent,
    BubbleInfoComponent
  ],
  entryComponents: [  
    BubbleInfoComponent     
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AgmCoreModule.forRoot({
      apiKey : 'AIzaSyBTwa3R0lj7_pEs50-AlywtIls_glWwYn4'
    }),
    
    BrowserAnimationsModule,
    MatDialogModule,
    MatFormFieldModule
  ],
  providers: [PaginationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
