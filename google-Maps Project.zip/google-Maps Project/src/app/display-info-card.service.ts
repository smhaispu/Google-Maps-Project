import { Injectable } from '@angular/core';
declare const google: any;
@Injectable({
  providedIn: 'root'
})
export class DisplayInfoCardService {
lat;
lng;
zoom;
  constructor() { }
  displayCardInfo(filteredItems){
 
      this.lat= filteredItems[0].latitude;
      this.lng = filteredItems[0].longitude;
      this.zoom= 15;
      let mapResult = this.resetMapCoordinates(filteredItems,this.zoom);

      let contentString= `<div class="info-window">
      <h3>Pin Code : ${filteredItems[0].address}</h3>
      <div class="info-content">
      <p>Latitude: ${filteredItems[0].latitude}</p>
      <p>Longitude: ${filteredItems[0].latitude}</p>
      </div>
      </div>`;
       let infowindow = new google.maps.InfoWindow({
        content: contentString,
        maxWidth: 1000
       });
    //    marker.addListener('click', 'domready',function () {
    //     infowindow.open(map, marker);
    // });
    infowindow.open(mapResult.map,mapResult.marker);
    google.maps.event.addListener(mapResult.marker, 'click', function() {
      infowindow.open(mapResult.map,mapResult.marker);
    });
    google.maps.event.addListener(mapResult.map, 'click', function() {
      infowindow.close();
    });
  
 
}

resetMapCoordinates(filteredItems,zoom){
  let map,marker;
  var bounds = new google.maps.LatLngBounds();
  
  if(filteredItems.length > 1){
    createMarker(zoom);
    for(let i=0;i<filteredItems.length && i < 50;i++){
      this.lat= filteredItems[i].latitude;
      this.lng = filteredItems[i].longitude;
      
      let location = new google.maps.LatLng(this.lat, this.lng);
      bounds.extend(location);
      console.log(this.lat,this.lng);

      marker = new google.maps.Marker({
        position: location,
        map: map
      
    });
  }
  map.fitBounds(bounds);
}else {
  this.lat= filteredItems[0].latitude;
  this.lng = filteredItems[0].longitude;
  createMarker(zoom);
 
  let location = new google.maps.LatLng(this.lat, this.lng);
  bounds.extend(location);
  console.log(this.lat,this.lng);

  marker = new google.maps.Marker({
    position: location,
    map: map
  
});
map.fitBounds(bounds);
}
function createMarker(zoom){
  let mapCanvas = document.getElementById('mapCanvas');
  let mapOptions = {
    zoom:zoom,
    panControl: false,
    mapTypeId: google.maps.MapTypeId.ROADMAP
};

  map = new google.maps.Map(mapCanvas, mapOptions);
}



return {
  'map':map,
  'marker':marker
}
}
}
