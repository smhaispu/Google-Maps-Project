import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataService } from '../data.service';
import { Subscription } from 'rxjs';
import { ItemsInterface } from '../models/pincodeItems';
import { PaginationService } from '../pagination.service';
import { MatDialog } from '@angular/material';
import { DisplayInfoCardService } from '../display-info-card.service';


@Component({
  selector: 'app-pin-search',
  templateUrl: './pin-search.component.html',
  styleUrls: ['./pin-search.component.css']
})
export class PinSearchComponent implements OnInit, OnDestroy {
  items: ItemsInterface[];
  lat: number;
  lng: number;
  pager: any = {};
  subs: Subscription;
  filteredItems;
  zoom: number = 1.5;
  pagedItems: any[];
  markerItem;
  constructor(private http: HttpClient,
    private dataservice: DataService,
    private PaginationService: PaginationService,
    public dialog: MatDialog,
    private displayCard: DisplayInfoCardService) {
    this.pager.currentPage = 1;
  }
  ngOnInit() {
    this.subs = this.dataservice.getData().subscribe(data => {
      this.items = data as ItemsInterface[];
     this.markerItem = this.filteredItems = this.items.slice(0, 10);
    });
  }
  ngOnDestroy() {
    this.subs.unsubscribe();
  }

  setLocationMarker(search: string) {
    
   this.displayCard.displayCardInfo(this.filteredItems);
   this.markerItem= this.filteredItems;
   

  }


  filterPinCode(search: string) {
    this.filteredItems = (search) ?
      this.items.filter(item => item.address.toString().includes(search)) :
      this.items.slice(0, 10)
    this.pager = this.PaginationService.getPager(this.items.length);
    if(search.length < 4){
      
      if(this.filteredItems){
       
          this.displayCard.resetMapCoordinates(this.filteredItems,1.5);
       

      }
      
      this.markerItem = this.filteredItems;
    }
    else{
      this.setLocationMarker(search);
    }
   
  }
  setPage(page: number) {
    if (page < 1 || page > 250) {
      return;
    }
    this.pager = this.PaginationService.getPager(this.items.length, page);
    console.log(this.pager);
    this.filteredItems = this.items.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }
}


