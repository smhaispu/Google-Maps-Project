import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PinSearchComponent } from './pin-search.component';

describe('PinSearchComponent', () => {
  let component: PinSearchComponent;
  let fixture: ComponentFixture<PinSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PinSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
